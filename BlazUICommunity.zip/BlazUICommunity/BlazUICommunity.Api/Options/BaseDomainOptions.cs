﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Blazui.Community.Api.Options
{
    public class BaseDomainOptions
    {
        public string BaseDomain { get; set; }
    }
}
