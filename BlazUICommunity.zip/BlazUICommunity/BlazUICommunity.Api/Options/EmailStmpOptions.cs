﻿namespace Blazui.Community.Api.Options
{
    public class EmailStmpOptions
    {
        /// <summary>
        ///
        /// </summary>
        public string Account { get; set; }

        /// <summary>
        ///
        /// </summary>
        public string Auth { get; set; }

        /// <summary>
        ///
        /// </summary>
        public string StmpHost { get; set; }

        /// <summary>
        ///
        /// </summary>
        public int StmpPort { get; set; }

        /// <summary>
        ///
        /// </summary>
        public string FromName { get; set; }
    }
}