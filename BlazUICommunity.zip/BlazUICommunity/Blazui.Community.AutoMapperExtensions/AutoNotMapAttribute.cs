﻿using System;

namespace Blazui.Community.AutoMapperExtensions
{
    public class AutoNotMapAttribute : Attribute
    {
    }
}