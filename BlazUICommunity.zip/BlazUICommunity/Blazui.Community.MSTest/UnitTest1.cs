using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Blazui.Community.MSTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}