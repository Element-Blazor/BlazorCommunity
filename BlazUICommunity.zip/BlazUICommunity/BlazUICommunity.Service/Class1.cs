﻿using System;

namespace BlazUICommunity.Service
{
    public class Class1
    {
    }
}
