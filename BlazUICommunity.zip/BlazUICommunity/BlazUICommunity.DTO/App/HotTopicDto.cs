﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blazui.Community.DTO
{
   public class HotTopicDto
    {

        public string Id { get; set; }
        public string Title { get; set; }

    }
}
