﻿namespace Blazui.Community.DTO
{
    public partial class UserActiveDto
    {
        public string UserId { get; set; }

        public int Count { get; set; }

        public string Name { get; set; }
    }
}