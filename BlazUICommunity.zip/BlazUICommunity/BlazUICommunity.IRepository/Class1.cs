﻿using System;

namespace BlazUICommunity.IRepository
{
    public class Class1
    {
    }
}
