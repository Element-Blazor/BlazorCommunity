﻿using System;

namespace BlazUICommunity.Interface
{
    public class Class1
    {
    }
}
