﻿namespace Blazui.Community.Request
{
    public class BannerReuestCondition : BaseRequestCondition
    {
    }
}