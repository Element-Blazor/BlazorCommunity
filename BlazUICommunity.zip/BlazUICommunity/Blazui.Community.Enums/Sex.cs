﻿using System.ComponentModel;

namespace Blazui.Community.Enums
{
    public enum Sex
    {
        [Description("男")]
        Man,

        [Description("女")]
        WoMan
    }
}