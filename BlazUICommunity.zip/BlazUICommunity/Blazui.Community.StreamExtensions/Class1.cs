﻿using System;

namespace Blazui.Community.StreamExtensions
{
    public class Class1
    {
    }
}
