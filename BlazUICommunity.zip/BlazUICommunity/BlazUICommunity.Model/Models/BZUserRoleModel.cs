﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Blazui.Community.Model.Models
{
   //public class BZUserRoleModel: IdentityUserRole<string>
   // {

   // }
}
