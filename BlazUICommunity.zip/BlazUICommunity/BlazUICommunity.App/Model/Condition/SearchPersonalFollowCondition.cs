﻿namespace Blazui.Community.App.Model.Condition
{
    public class SearchPersonalFollowCondition : BaseSearchCondition
    {
        public string TopicTitle { get; set; }
    }
}