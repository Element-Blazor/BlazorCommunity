﻿namespace Blazui.Community.App.Model
{
    public class NewReplyModel
    {
        public string Content { get; set; } = string.Empty;
    }
}