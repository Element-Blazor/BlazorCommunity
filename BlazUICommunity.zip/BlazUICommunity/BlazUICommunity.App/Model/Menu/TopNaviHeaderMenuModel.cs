﻿namespace Blazui.Community.App.Model
{
    public class TopNaviHeaderMenuModel
    {
        public string Title { get; set; }
        public string URL { get; set; }
        public string Icon { get; set; }
    }
}