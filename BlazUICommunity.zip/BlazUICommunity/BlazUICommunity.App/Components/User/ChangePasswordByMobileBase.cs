﻿using Blazui.Community.App.Pages;

namespace Blazui.Community.App.Components.User
{
    public class ChangePasswordByMobileBase : PageBase
    {
    }
}