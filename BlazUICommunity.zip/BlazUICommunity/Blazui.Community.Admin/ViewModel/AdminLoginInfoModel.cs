﻿namespace Blazui.Community.Admin.ViewModel
{
    public class AdminLoginInfoModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}