﻿namespace Blazui.Community.Admin.Enum
{
    public enum EntryOperation
    {
        Add,
        Delete,
        Update
    }
}