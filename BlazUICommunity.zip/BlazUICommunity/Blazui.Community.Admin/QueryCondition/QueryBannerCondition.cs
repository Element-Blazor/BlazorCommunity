﻿namespace Blazui.Community.Admin.QueryCondition
{
    public class QueryBannerCondition : BaseQueryCondition
    {
    }
}