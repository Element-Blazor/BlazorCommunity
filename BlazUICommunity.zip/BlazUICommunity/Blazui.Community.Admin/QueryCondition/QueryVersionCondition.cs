﻿using Blazui.Community.Enums;

namespace Blazui.Community.Admin.QueryCondition
{
    public class QueryVersionCondition : BaseQueryCondition
    {
        public ProjectType? ProjectId { get; set; }
    }
}